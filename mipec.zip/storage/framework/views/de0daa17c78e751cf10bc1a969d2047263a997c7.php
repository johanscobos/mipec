<?php
use App\Cliente;
use App\Servicio;
use Illuminate\Support\Facades\Auth;
?>

<?php $__env->startSection('title','Clientes - Servicios pendientes de pago'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Servicios por pagar</h2>

    <?php
        $user = Auth::user();
        $email = Auth::user()->email;
        $user_id = Auth::user()->id;
        $cliente = Cliente::find(3);
    //dd($user);
    ?>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">Id Servicio</th>
            <th scope="col">Valor $</th>

            <th scope="col">Descripcion</th>
            <th scope="col">Pagar</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cliente->servicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cli): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <tr>
            <td>
                <?php
               echo $cli->pivot->servicio_id;
                ?>
            </td>

            <td>
                <?php
                    echo $cli->pivot->valor_pagar;
                ?>
            </td>
            <td>
                <?php
                    echo $cli->descripcion;
                ?>
            </td>
            <td>
                <!-- se enlaza con el formulario de pago-, debe ser por POST-->
                <?php echo Form::open(['route' => 'clientes.formupago', 'method' => 'post']); ?>


                <?php echo Form::hidden('servicio_id',$cli->pivot->servicio_id); ?>

                <?php echo Form::hidden('amount',$cli->pivot->valor_pagar); ?>

                <?php echo Form::hidden('descripcion_variable',$cli->pivot->descripcion_variable); ?>

                <?php echo Form::hidden('description',$cli->descripcion); ?>

                <?php echo Form::hidden('currency',$cli->descripcion); ?>

                <?php echo Form::hidden('buyerFullName',$cli->descripcion); ?>

                <?php echo Form::hidden('buyerEmail',$email); ?>

                <?php echo Form::hidden('shippingAddress',$cli->direccion); ?>

                <?php echo Form::hidden('shippingCity',$cli->descripcion); ?>

                <?php echo Form::hidden('shippingCity',$cli->descripcion); ?>

                <?php echo Form::hidden('shippingCountry',$cli->descripcion); ?>

                <?php echo Form::hidden('telephone',$cli->descripcion); ?>

                <?php echo Form::hidden('signature','7ee7cf808ce6a39b17481c54f2c57acc') ;; ?>

                <?php echo Form::hidden('referenceCode','AAA1254578') ;; ?>

                <?php echo Form::hidden('merchantId','688911') ;; ?>

                <?php echo Form::hidden('accountId','691796') ;; ?>

                <?php echo Form::hidden('buyerFullName','Albert Cobos Palma') ;; ?>

                <?php echo Form::hidden('tax');; ?>

                <?php echo Form::hidden('taxReturnBase','0') ;; ?>

                <?php echo Form::hidden('currency') ;; ?>

                <?php echo Form::hidden('shippingCity','Pereira') ;; ?>

                <?php echo Form::hidden('shippingCountry','57') ;; ?>

                <?php echo Form::hidden('telephone','3204190555') ;; ?>


                <?php echo Form::submit('Pagar',['class' => 'btn btn-danger']);; ?>

                <?php echo Form::close(); ?>


            </td>
        </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>