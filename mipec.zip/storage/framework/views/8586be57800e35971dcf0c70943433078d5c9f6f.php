<?php
    use App\Cliente;
    use App\Servicio;
    use Illuminate\Support\Facades\Auth;
?>


<?php $__env->startSection('title','Clientes - Gestionar clientes'); ?>
<?php $__env->startSection('content'); ?>

    <h1>Gestionar Servicios de Cliente</h1>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">Cliente</th>
            <th scope="col">Cédula</th>
            <th scope="col">Ref.</th>
            <th scope="col">Servicio</th>
            <th scope="col">Acción</th>

        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clservicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clservicios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <?php
                    $cliente_id=$clservicios->cliente_id;
                    $rc=$clservicios->referenceCode;
                    $estado_servicio_actual=$clservicios->estado_servicio;
                    $cliente = App\Cliente::find($cliente_id);
                    echo $cliente->nombres.' '.$cliente->apellido1.' '.$cliente->apellido2;
                    ?>
                </td>
               <td>
                   <?php
                       echo $cliente->cedula;
                   ?>
               </td>
                <td>
                    <?php
                        echo $clservicios->referenceCode;
                    ?>
                </td>

                <td>
                    <?php
                        $servicio_id=$clservicios->servicio_id;
                        $servicio = App\Servicio::find($servicio_id);
                        echo $servicio->nombre;
                    ?>
                </td>
                <td>
                    <?php echo Form::open(['route' => 'clientes.activarcliente', 'method' => 'post']); ?>

                    <?php if($estado_servicio_actual==0): ?>

                    <?php echo Form::submit('Activar',['class' => 'btn btn-primary']);; ?>

                        <?php echo Form::hidden('cliente_id',$cliente_id ); ?>

                        <?php echo Form::hidden('rc',$rc ); ?>

                        <?php echo Form::hidden('accion','1' ); ?>

                    <?php else: ?>
                        <?php echo Form::submit('Inactivar',['class' => 'btn btn-danger']);; ?>

                        <?php echo Form::hidden('id',$cliente_id ); ?>

                        <?php echo Form::hidden('rc',$rc ); ?>

                        <?php echo Form::hidden('accion','0' ); ?>

                    <?php endif; ?>
                    <?php echo Form::close(); ?>

                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>