<?php $__env->startSection('content'); ?>
    <h2>Registrar usuarios</h2>

<?php echo Form::open(['route' => 'administrador.store', 'method' => 'post', 'novalidate' => 'novalidate']); ?>


    <?php echo Form::label('Nombre de usuario', 'Username');; ?>

    <?php echo Form::text('username',null, ['class' => 'form-control'],$attributes=['required']);; ?>

    <br>
    <?php echo Form::label('email', 'Correo electronico');; ?>

    <?php echo Form::email('email',null, ['class' => 'form-control'],$attributes=['required']);; ?>

    <br>
    <?php echo Form::label('tipo_user', 'Tipo de usuario');; ?>

    <?php echo Form::select('tipo_user',[-1=>'seleccione una opcion',1 => 'Cliente', 0 => 'Empleado' ],null, $attributes=['required']);; ?>

    <br>
    <?php echo Form::label('password', 'Contraseña');; ?>

    <?php echo Form::password('password', ['class' => 'awesome form-control']);; ?>


    <br>

    
    <div id="formulario-empleado" style="display:none;">
        <?php echo Form::label('cedula', 'Número de cedula :');; ?>

        <?php echo Form::text('cedulaem',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('nombres', 'Nombre del empleado :');; ?>

        <?php echo Form::text('nombresem',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('apellidos', 'Apellidos :');; ?>

        <?php echo Form::text('apellidosem',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('telefono', 'Número de telefono :');; ?>

        <?php echo Form::text('telefonoem',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('celular', 'Número de celular :');; ?>

        <?php echo Form::text('celularem',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('direccion', 'Dirección :');; ?>

        <?php echo Form::text('direccionem',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        
        <?php echo Form::label('paises', 'Pais: ');; ?>

            <select name="paises">
        <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value= <?php echo e($pais->codigo); ?>><?php echo e($pais->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        
        <?php echo Form::label('ciudades', 'Ciudad: ');; ?>

        <select name="ciudades">
        <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value= <?php echo e($ciudad->id); ?>><?php echo e($ciudad->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>

    </div>

    <div id="formulario-cliente" style="display:none;">
        <?php echo Form::label('cedula', 'Número de cedula :');; ?>

        <?php echo Form::text('cedula',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('nombres', 'Nombre del empleado :');; ?>

        <?php echo Form::text('nombres',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('apellidos', 'Apellidos :');; ?>

        <?php echo Form::text('apellidos',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('telefono', 'Número de telefono :');; ?>

        <?php echo Form::text('telefono',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('celular', 'Número de celular :');; ?>

        <?php echo Form::text('celular',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        <?php echo Form::label('direccion', 'Dirección :');; ?>

        <?php echo Form::text('direccion',null, ['class' => 'form-control'],$attributes=['required']);; ?>

        <br>
        
        <?php echo Form::label('paises', 'Pais: ');; ?>

            <select name="paises">
        <?php $__currentLoopData = $paises; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pais): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value= <?php echo e($pais->codigo); ?>><?php echo e($pais->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>
        
        <?php echo Form::label('ciudades', 'Ciudad: ');; ?>

        <select name="ciudades">
        <?php $__currentLoopData = $ciudades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ciudad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value= <?php echo e($ciudad->id); ?>><?php echo e($ciudad->nombre); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>



    </div>


    <?php echo Form::submit('Registrar',['class' => 'btn btn-primary']);; ?>

<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

    <script type="text/javascript">

        $(document).ready(function(){
            $("#tipo_user").on("change", function(){
                if(($('select[id=tipo_user]').val()) == 1){
                    $("#formulario-cliente").show();
                    $("#formulario-empleado").hide();
                }
                if(($('select[id=tipo_user]').val()) == 0){
                    $("#formulario-empleado").show();
                    $("#formulario-cliente").hide();
                }

            });});

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>