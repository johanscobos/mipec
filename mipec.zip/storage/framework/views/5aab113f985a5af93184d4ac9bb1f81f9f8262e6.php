<?php
    use App\Cliente;
    use App\Servicio;
    use Illuminate\Support\Facades\Auth;
?>

<?php $__env->startSection('title','Clientes - Servicios pendientes de pago'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Mis Servicios por pagar</h2>

    <?php
       $email = Auth::user()->email;
      ?>

    <?php if(count($pagospendientes)==0): ?>
        <h3>A la fecha, no tiene pagos pendietes</h3>
    <?php else: ?>
        <table class="table">
        <thead>
        <tr>
            <th scope="col">Servicio</th>
            <th scope="col">Ref. Unica</th>
            <th scope="col">Valor $</th>
            <th scope="col">Descripcion</th>
            <th scope="col">Acción</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pagospendientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                <?php
                    //Instancio el servicio con el id
                     $servicio = App\Servicio::find($pp->servicio_id);

                    //Instancio el cliente con el id
                     $cliente = App\Cliente::find($pp->cliente_id);
                ?>
            <tr>
                <td>
                    <?php
                      echo $servicio->nombre;
                    ?>
                </td>
                <td>
                    <?php
                        echo $pp->referenceCode;
                    ?>
                </td>
                <td>
                    <?php
                        echo $pp->valor_pagar;
                    ?>
                </td>
                <td>
                    <?php
                        echo $descripcion=$servicio->descripcion.'. '.$pp->descripcion_variable;
                    $apikey="K4mvTeqzoeATzM5F72DVP3O8VO";
                    $merchantId="688911";
                    $reference=$pp->referenceCode;
                   // dd($reference);
                    $amount=$pp->valor_pagar;
                    $moneda="COP";

                    $dat=$apikey.'~'.$merchantId.'~'.$reference.'~'.$amount.'~'.$moneda;
                    //dd($dat);
                    //$firm=hash('md5', $dat);
                     $sign=md5($dat);
                    // dd($firm);




                    ?>
                </td>
                <td>
                <?php echo Form::open(['url' => 'https://sandbox.gateway.payulatam.com/ppp-web-gateway/', 'method' => 'post']); ?>




                    <?php echo Form::hidden('merchantId','508029') ;; ?>

                    <?php echo Form::hidden('ApiKey','4Vj8eK4rloUd272L48hsrarnUA') ;; ?>

                    <?php echo Form::hidden('referenceCode','MIPEC14585') ;; ?>

                    <?php echo Form::hidden('description','Test PAYU'); ?>

                    <?php echo Form::hidden('amount','3500'); ?>

                    <?php echo Form::hidden('tax','0');; ?>

                    <?php echo Form::hidden('taxReturnBase','0') ;; ?>

                    <?php echo Form::hidden('signature','0944d4f46c56456913609efa55f2150a') ;; ?>

                    <?php echo Form::hidden('accountId','512321') ;; ?>

                    <?php echo Form::hidden('currency','USD'); ?><!-- COL -->
                    <?php echo Form::hidden('test','1'); ?>

                    <?php echo Form::hidden('buyerEmail','test@test.com'); ?>



                    <?php echo Form::submit('Pagar',['class' => 'btn btn-danger']);; ?>


                    <?php echo Form::close(); ?>






                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>