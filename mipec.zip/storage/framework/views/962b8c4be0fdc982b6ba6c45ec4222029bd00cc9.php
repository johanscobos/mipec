<?php $__env->startSection('content'); ?>

    <h2>Asignar Empleado a Cliente</h2>

  <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">Id</th>
            <th scope="col">Cliente</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($cliente->id); ?></th>
                <td><?php echo e($cliente->nombres. ' '.$cliente->apellidos); ?></td>
                
                
                    <td><a href="<?php echo e(route('clienteEmpleado',$cliente->id)); ?>" class="btn btn-danger">Asociar cliente a empleado</a> </td>
                
                    
                

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
        </tbody>
    </table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>