<?php
    use App\Cliente;
    use App\Servicio;
    use Illuminate\Support\Facades\Auth;
?>


<?php $__env->startSection('title','Clientes - Gestionar Servicios'); ?>
<?php $__env->startSection('content'); ?>

    <h1>Activar / Inactivar Servicio</h1>

    <?php echo Form::open(['route' => 'clientes.gestionar_servicios', 'method' => 'get']); ?>


        <?php echo Form::label('cedula','Ingrese cédula del cliente' ); ?>

        <?php echo Form::text('cedula' ); ?>

        <?php echo Form::submit('Buscar',['class' => 'btn btn-primary']);; ?>

        <?php echo Form::submit('Eliminar filtro',['class' => 'btn btn-primary']);; ?>


    <?php echo Form::close(); ?>


    <?php if(isset($clservicios)): ?>
    <table class="table">
        <thead>
        <tr>
            <th scope="col">Cliente</th>
            <th scope="col">Cédula</th>
            <th scope="col">Ref.</th>
            <th scope="col">Servicio</th>
            <th scope="col">Acción</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $clservicios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clservicios): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <tr>
                <td>
                    <?php
                        $cliente_id=$clservicios->cliente_id;
                        $servicio_id=$clservicios->servicio_id;
                        $rc=$clservicios->referenceCode;
                        $estado_servicio_actual=$clservicios->estado_servicio;
                        $cliente = App\Cliente::find($cliente_id);
                        echo $cliente->nombres.' '.$cliente->apellido1.' '.$cliente->apellido2;
                    ?>
                </td>
                <td>
                    <?php
                        echo $cliente->cedula;
                    ?>
                </td>
                <td>
                    <?php
                        echo $clservicios->referenceCode;
                    ?>
                </td>

                <td>
                    <?php
                        $servicio_id=$clservicios->servicio_id;
                        $servicio = App\Servicio::find($servicio_id);
                        echo $servicio->nombre;
                    ?>
                </td>
                <td>

                    <?php if($estado_servicio_actual==0): ?>



                        <?php echo Form::open(['route' => 'clientes.activar_inactivar_servicio', 'method' => 'post']); ?>

                        <?php echo Form::submit('Activar',['class' => 'btn btn-primary']);; ?>

                        <?php echo Form::hidden('cliente_id',$cliente_id ); ?>

                        <?php echo Form::hidden('rc',$rc ); ?>

                        <?php echo Form::hidden('accion','1' ); ?>

                        <?php echo Form::close(); ?>



                    <?php else: ?>
                        <?php echo Form::open(['route' => 'clientes.activar_inactivar_servicio', 'method' => 'post']); ?>

                        <?php echo Form::submit('Inactivar',['class' => 'btn btn-danger']);; ?>

                        <?php echo Form::hidden('cliente_id',$cliente_id ); ?>

                        <?php echo Form::hidden('rc',$rc ); ?>

                        <?php echo Form::hidden('accion','0' ); ?>

                        <?php echo Form::close(); ?>

                        <?php endif; ?>



                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

    <?php else: ?>
        <b>NO hay servicios asociados para clientes con este documento!!</b>
    <?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>