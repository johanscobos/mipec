<?php $__env->startSection('title','Clientes - Servicios pendientes de pago'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Servicios por pagar</h2>


    <table class="table">
        <thead>
        <tr>
            <th scope="col">Id</th>
            <th scope="col">valor</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo $cl['0'];; ?></td>

        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>