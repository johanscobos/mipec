<?php $__env->startSection('content'); ?>

        <h2>Buscar Empleado</h2>
        <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo Form::open(['route' => 'guardarRelacion', 'method' => 'post', 'novalidate' => 'novalidate']); ?>



 <?php echo Form::hidden('id',$value=$id, $attributes=['required']);; ?>


<?php echo Form::label('empleados', 'Empleado: ');; ?>

        <select name="empleados">
        <?php $__currentLoopData = $empleado; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $empleado): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value= <?php echo e($empleado->id); ?>><?php echo e($empleado->nombres); ?></option>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <br>

<?php echo Form::submit('Relacionar',['class' => 'btn btn-primary']);; ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>