<?php $__env->startSection('title','Clientes - Planillas'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Planillas</h2>
    <?php echo Form::open(['route' => 'clientes.subir_planilla', 'method' => 'put', 'files' => true]); ?>


    <?php echo Form::label ('planilla', 'Planilla'); ?><br>
    <?php echo Form::file('planilla'); ?><br>
    <?php echo $errors->first('planilla','<span class=error>:message</span>'); ?>

    <br>
    <?php echo Form::submit('Subir',['class' => 'btn btn-primary']);; ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>