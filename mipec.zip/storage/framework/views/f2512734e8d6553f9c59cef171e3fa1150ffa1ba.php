<?php
    use App\User;
?>


<?php $__env->startSection('title','Clientes - Mi historial de pagos'); ?>
<?php $__env->startSection('content'); ?>

    <h1>Mi historial de pagos</h1>
    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <nav class="navbar navbar-light bg-light">
        <?php echo Form::open(['method' => 'get', 'class'=>'form-inline','role'=>'search']); ?>

        <div class="form-group">
            <?php echo Form::text('dato',null,['class' => 'form-control mr-sm-2', 'placeholder' => 'Ref. Pago'] ); ?>

            <div class="form-group">
        <?php echo Form::submit('Buscar',['class' => 'btn btn-outline-success my-2 my-sm-0']);; ?>


        <?php echo Form::close(); ?>

    </nav>

    <table class="table table-striped">
        <thead>
        <tr>
            <th scope="col">#</th>
            <th scope="col">Servicio</th>
            <th scope="col">Referencia de Pago</th>
            <th scope="col">Valor pagado</th>
            <th scope="col">Acción</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $pagos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pago): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($pago->id); ?></th>
                <td><?php echo e($pago->datosservicio->nombre); ?></td>
                <td><?php echo e($pago->referenceCode); ?></td>
                <td><?php echo e('$ '.$pago->valor_pago); ?></td>

                <?php if($pago->datosservicio->id ==1): ?>
                    <td><a href="<?php echo e(route('clientes.pagos.bajar_planilla',$pago->id)); ?>" class="btn btn-danger">D. Planilla</a> <a href="" class="btn btn-warning">Detalles</a></td>
                <?php else: ?>
                    <td><a href="" class="btn btn-warning">Detalles</a></td>
                <?php endif; ?>

            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>