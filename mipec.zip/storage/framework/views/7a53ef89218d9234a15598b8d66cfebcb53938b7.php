<?php $__env->startSection('title','Realizar Pago'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Formulario de pago</h2>
    <?php echo Form::open(['url' => 'https://sandbox.gateway.payulatam.com/ppp-web-gateway/', 'method' => 'post']); ?>


    <div class="form-group">
        <?php echo Form::hidden('merchantId') ;; ?>

        <?php echo Form::hidden('referenceCode') ;; ?>

        <?php echo Form::text('description') ;; ?>

        <?php echo Form::text('descripcion_variable');; ?>

        <?php echo Form::text('amount') ;; ?>

        <?php echo Form::hidden('tax');; ?>

        <?php echo Form::hidden('taxReturnBase') ;; ?>

        <?php echo Form::hidden('signature') ;; ?>

        <?php echo Form::hidden('accountId') ;; ?>

        <?php echo Form::hidden('currency') ;; ?>

        <?php echo Form::hidden('buyerFullName') ;; ?>

        <?php echo Form::text('buyerEmail') ;; ?>

        <?php echo Form::hidden('shippingAddress','') ;; ?>

        <?php echo Form::hidden('shippingCity') ;; ?>

        <?php echo Form::hidden('shippingCountry') ;; ?>

        <?php echo Form::hidden('telephone') ;; ?>

        <br>


        <?php echo Form::submit('Enviar');; ?>

        <?php echo Form::close(); ?>

    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>