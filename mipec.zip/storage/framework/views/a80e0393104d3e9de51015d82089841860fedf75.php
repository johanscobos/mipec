<?php $__env->startSection('title','Clientes - Asignar Servicios'); ?>
<?php $__env->startSection('content'); ?>


    <h2>Asignar Servicios</h2>
    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::open(['route' => 'clientes.store', 'method' => 'post']); ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <p class="alert alert-danger"><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group">
        <?php echo Form::label('clientes', 'Nombre del cliente');; ?>

        <?php echo Form::select('cliente_id',$clientes, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('servicios', 'Nombre del Servicio');; ?>

        <?php echo Form::select('servicio_id',$servicios, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('valor_pagar', 'Valor del servicio');; ?>

        <?php echo Form::number('valor_pagar',null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('descripcion_variable', 'Descripcion variable');; ?>

        <?php echo Form::text('descripcion_variable',null, ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('estado_pago', 'Estado de Pago');; ?>

        <?php echo Form::select('estado_pago', ['0' => 'Inactivo', '1' => 'Activo'], ['class' => 'form-control']); ?>

    </div>
    <div class="form-group">
        <?php echo Form::label('estado_servicios', 'Estado Servicio');; ?>

        <?php echo Form::select('estado_pago', ['0' => 'Inactivo', '1' => 'Activo'], ['class' => 'form-control']); ?>

    </div>

    <br>
    <?php echo Form::submit('Enviar',['class' => 'btn btn-primary']);; ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>