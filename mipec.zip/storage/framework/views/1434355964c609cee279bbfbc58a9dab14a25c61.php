<?php $__env->startSection('content'); ?>

	<h2>Ver mis Clientes</h2>



<table class="table table-striped">
	<thead>
	<tr>
		<th scope="col">Id</th>
		<th scope="col">Nombre</th>
		<th scope="col">Cédula</th>

		<th scope="col">Acción</th>
	</tr>
	</thead>
	<tbody>
	<?php $__currentLoopData = $cliente; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th scope="row"><?php echo e($cliente->id); ?></th>
			<td><?php echo e($cliente->nombres. ' '.$cliente->apellidos); ?></td>
			<td><?php echo e($cliente->cedula); ?></td>
            <td><a href="" class="btn btn-warning">D</a></td>


		</tr>
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</tbody>
</table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>