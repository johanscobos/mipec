<ul>
    <li><a href="<?php echo e(url('admin/clientes/create')); ?>">Crear Usuarios</a></li>
    <li><a href="<?php echo e(url('admin/empleados/create')); ?>">Crear Cargos</a></li>
    <li><a href="<?php echo e(url('admin/empleados/create')); ?>">Crear Servicios</a></li>
    <li><a href="<?php echo e(url('admin/clientes/gestionar_servicios')); ?>">Gestionar Servicios Cliente</a></li>
    <li><a href="<?php echo e(url('admin/clientes/subir_planilla')); ?>">Subir Planilla</a></li>
</ul>