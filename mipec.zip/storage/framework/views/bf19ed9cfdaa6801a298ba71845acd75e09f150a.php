<?php $__env->startSection('title','Crear Servicios'); ?>
<?php $__env->startSection('content'); ?>

    <h2>Crear Servicios</h2>
    <?php echo $__env->make('flash::message', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <?php echo Form::open(['route' => 'servicios.store', 'method' => 'post']); ?>

    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <p class="alert alert-danger"><?php echo e($error); ?></p>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group">
        <?php echo Form::label('servicio', 'Nombre del servicio');; ?>

        <?php echo Form::text('nombre',null,['class' => 'form-control'], $attributes=['required']) ;; ?>


        <?php echo Form::label('descripcion', 'Descripción');; ?>

        <?php echo Form::text('descripcion',null,['class' => 'form-control'], $attributes=['required']) ;; ?>

    </div>

    <br>
    <?php echo Form::submit('Enviar',['class' => 'btn btn-primary']);; ?>

    <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.principal', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>