<ul class="lista">
	<b>Administrador</b><br>
    <li><a href="<?php echo e(url('admin/administrador/create')); ?>">Crear Usuarios</a></li>
    <li><a href="<?php echo e(url('admin/servicios/create')); ?>">Crear Servicios</a></li>
    <li><a href="<?php echo e(url('admin/administrador/clienteEmpleado')); ?>">Asignar empleado a cliente</a></li>

    <li><a href="<?php echo e(url('admin/clientes/asignarservicio')); ?>">Asignar servicio a cliente</a></li>
    <li><a href="<?php echo e(url('/clientes/pagos')); ?>">Listar Pagos de Clientes</a></li>

    <li><a href="<?php echo e(url('admin/clientes/gestionar_servicios')); ?>">Activar/Inactivar Servicio</a></li>



    <b>Clientes</b><br>
    <li><a href="<?php echo e(url('clientes/pagos/pagospendientes')); ?>">Servicios por pagar</a></li>

    <li><a href="<?php echo e(url('/clientes/pagos/ver_pagos')); ?>">Historial de pagos</a></li>

    <b>Empleados</b>
    <li><a href="<?php echo e(url('admin/empleados/verClientes')); ?>">Ver mis clientes</a></li>
</ul>