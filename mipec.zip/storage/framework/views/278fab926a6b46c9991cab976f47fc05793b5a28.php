<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Styles -->

    <link href="<?php echo e(asset('/css/bootstrap.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('/css/layout.css')); ?>" rel="stylesheet">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <title>Admin - <?php echo $__env->yieldContent('title'); ?></title>

</head>
<body>
<?php echo $__env->make('layouts.partials.header', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="container-flex cont">
        <div class="sidebar">
                <?php echo $__env->make('layouts.partials.sidebar-menu', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="contenido">
            <?php echo $__env->yieldContent('content'); ?>
        </div>

</div>

<?php echo $__env->make('layouts.partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>



<!-- Scripts -->
<script src="<?php echo e(asset('js/jquery-3.2.1.js')); ?>"></script>
<script src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>


