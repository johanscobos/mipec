<ul>
    <li><a href="{{url('admin/administrador/create')}}">Crear Usuarios</a></li>
    <li><a href="{{url('admin/administrador/clienteEmpleado')}}">Asignar empleado a cliente</a></li>
    <li><a href="{{url('admin/empleados/create')}}">Crear Cargos</a></li>
    <li><a href="{{url('admin/empleados/create')}}">Crear Servicios</a></li>
    <li><a href="{{url('admin/clientes/gestionar_servicios')}}">Gestionar Servicios Cliente</a></li>
    <li><a href="{{url('admin/clientes/subir_planilla')}}">Subir Planilla</a></li>
</ul>