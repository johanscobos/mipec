<ul>
    <li><a href="{{url('servicios')}}">Cliente</a></li>
    <li><a href="{{url('clientes/pagos/pagospendientes')}}">Servicios por pagar</a></li>
    <li><a href="{{url('admin/clientes/gestionar_servicios')}}">Historial de pagos</a></li>
    <li><a href="{{url('admin/clientes/gestionar_servicios')}}">Revisar Planillas</a></li>
</ul>