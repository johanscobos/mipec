@extends('layouts.principal')
@section('content')


<p>hola</p>
@endsection