@extends('layouts.principal')


@section('content')

    @include('flash::message')
    @endsection